### Qual a proposta ?


### Qual o Contexto ?


### Há algum aspecto de segurança a ser considerado ?
 

### Há algum risco mapeado ? Como mitigar ?


### Qual o indicador de sucesso e como podemos medir ?


### Links / Referências
