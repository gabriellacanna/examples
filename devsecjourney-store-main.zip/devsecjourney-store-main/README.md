# **DevSecJourney Store - Loja de jobs de CI/CD**
## **Descrição**
Esse projeto contém jobs que ao serem configurados em um repositório entregam uma esteira completa de CI/CD passando pelos padrões qualidade da Boa Vista.

## **Projeto com templates prontos**
Temos um projeto com templates prontos para a utilização que consomem os jobs deste repositório: https://gitlab.bvsnet.com.br/estruturantes/devsecjourney/devsecjourney-template-store 

Recomendamos fortemente que sejam utilizados os templates prontos ou colabore para criação de um novo template no repositório oficial para suprir alguma necessidade de sua squad. **MR são bem vindas :)**

Caso tenha interesse em colaborar vá até a sessão [Colaboração](#colaboração)


## **Organização**
os jobs estão organizados em pastas que remetem aos seus stages. A ordem dos stages definido deve ser:
```
    stages:
        - code
        - versioning
        - unit-test
        - package
        - dockerize
        - verify
        - secure
        - validate
        - release
        - publish
        - deploy
```   
Caso não siga esse padrão há chance de não funcionar como o esperado.

### **Stages**
Descrição dos stages
- code : Configuração inicial da esteira e lint
- versioning: Versionamento automatizado
- unit-test: Testes unitários
- package: Fase de build
- dockerize: Dockerização da aplicação
- verify: Verificações da qualidade do código
- secure: Verificações de segurança do código
- validade: Validação das informações da esteira como versionamento, gitflow, variáveis de ambiente obrigatórias
- release: Cria uma tag e/ou release com a versão
- publish: Publica uma versão no package registry e/ou no docker registry
- deploy: Faz deploy da aplicação


## **Colaboração**
Caso a mudança seja um novo job, ele deve estar de acordo com o stage descrito acima. Todas modificações devem ser previamente testadas antes de abrir uma MR.

Para testar o código dos jobs sugerimos que seja utilizado um novo repositório contendo um código fonte simples, que não faça nenhum tipo de processamento crítico e siga os passos abaixo
- No repositório teste será importado o job a ser testado utilizando o include e apontando para o seu branch do repositório "DevSecJourney Store"
- Você pode utilizar qualquer outro job já existente para concatenar à sua esteira de teste
- Você pode utilizar nossa loja de templates como exemplo de como importar templates https://gitlab.bvsnet.com.br/estruturantes/devsecjourney/devsecjourney-template-store
- Sugerimos a utilização do CI lint do gitlab para testes de sintaxe rápidas. Ele fica localizado na sessão CICD/pipelines

Após finalizar os testes manuais, abra uma MR descrevendo a motivação e anexe os links de sucesso do job. É recomendado que a MR tenha apenas um commit e siga o padrão https://www.conventionalcommits.org/en/v1.0.0/

Para inserir o job no repositório de templates por favor abra uma MR em https://gitlab.bvsnet.com.br/estruturantes/devsecjourney/devsecjourney-template-store