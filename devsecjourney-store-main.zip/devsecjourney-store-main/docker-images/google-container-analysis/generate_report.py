import json
import sys
from json2html import *
import os
import logging

logging.basicConfig(level=logging.INFO)


def generate_report(vulnerabilities, reports_folder):
    try:
        os.makedirs(reports_folder, exist_ok=True)
    except OSError:
        os_error_msg = "Could not create {} folder".format(reports_folder)
        logging.critical(os_error_msg)
        sys.exit(os_error_msg)
    for vulnerability_level, vulnerability_list in vulnerabilities.items():
        filename = "{}/{}.html".format(reports_folder, vulnerability_level)
        try:
            with open(filename, "w") as f:
                f.write(
                    '<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">'
                )
                f.write(
                    json2html.convert(
                        json=json.dumps(vulnerability_list),
                        table_attributes='class="table-sm table table-hover table-striped"',
                    )
                )
        except OSError:
            os_error_msg = "Could not open/writte file: {}".format(filename)
            logging.error(os_error_msg)
        except:
            generic_error_msg = "Unexpected error: {}".format(sys.exc_info()[0])
            logging.error(generic_error_msg)


def parse_vulnerabilities(vulnerabilities_file):
    try:
        with open(vulnerabilities_file, "r") as f:
            file_content = f.read()
            vulnerabilities = json.loads(file_content)
            parsed_vulnerabilities = {
                "critical": [],
                "high": [],
                "medium": [],
                "low": [],
                "undefined": [],
            }
            total_count = len(vulnerabilities)
            for i in vulnerabilities:
                i.pop("createTime")
                i.pop("kind")
                i.pop("name")
                i.pop("resourceUri")
                i.pop("updateTime")
                if "severity" in i["vulnerability"]:
                    if i["vulnerability"]["severity"] == "CRITICAL":
                        parsed_vulnerabilities["critical"].append(i)
                    elif i["vulnerability"]["severity"] == "HIGH":
                        parsed_vulnerabilities["high"].append(i)
                    elif i["vulnerability"]["severity"] == "MEDIUM":
                        parsed_vulnerabilities["medium"].append(i)
                    elif i["vulnerability"]["severity"] == "LOW":
                        parsed_vulnerabilities["low"].append(i)
                    else:
                        parsed_vulnerabilities["undefined"].append(i)
                else:
                    parsed_vulnerabilities["undefined"].append(i)
            return parsed_vulnerabilities, total_count
    except OSError:
        os_error_msg = "Could not open/read file: {}".format(vulnerabilities_file)
        logging.critical(os_error_msg)
        sys.exit(os_error_msg)
    except:
        generic_error_msg = "Unexpected error: {}".format(sys.exc_info()[0])
        logging.critical(generic_error_msg)
        sys.exit(generic_error_msg)

    


def print_summary(vulnerabilities, total_count):
    msg = """
        Detectamos um total de {} vulnerabilidades
--------------------------------------------------------------
        -- CRITICAL: {}
        -- HIGH: {}
        -- MEDIUM: {}
        -- LOW: {}
        -- UNDEFINED: {}
--------------------------------------------------------------
        Baixe o relatório completo na aba "Job Artifacts"
--------------------------------------------------------------
    """.format(
        total_count,
        len(vulnerabilities["critical"]),
        len(vulnerabilities["high"]),
        len(vulnerabilities["medium"]),
        len(vulnerabilities["low"]),
        len(vulnerabilities["undefined"]),
    )
    print(msg)


if __name__ == "__main__":
    if len(sys.argv) < 3:
        error_msg = "Not enought arguments"
        logging.critical(error_msg)
        sys.exit(error_msg)
    elif len(sys.argv) > 3:
        error_msg = "Too many arguments"
        logging.critical(error_msg)
        sys.exit(error_msg)
    vulnerabilities_file = sys.argv[1]
    if not os.path.isfile(vulnerabilities_file):
        os_error_msg = "Could not open/read file: {}".format(vulnerabilities_file)
        logging.critical(os_error_msg)
        sys.exit(os_error_msg)
    reports_folder = sys.argv[2]
    parsed_vulnerabilities, total_count = parse_vulnerabilities(vulnerabilities_file)
    print_summary(parsed_vulnerabilities, total_count)
    generate_report(parsed_vulnerabilities, reports_folder)
