# Contribuições

Contribuições com novos templates são bem vindas e estamos ansiosos para ver suas ideias. 

Se quer corrigir um problema ou dúvida, por favor, entre em contato com os proprietários deste repositório antes de solicitar a mudança.

## Criação do Template

A seguir está o link do [Guia para criação de templates](https://boavistaservicos.atlassian.net.mcas.ms/wiki/spaces/CP/pages/528711698/Guia+para+inclus+o+de+novos+templates) no qual é explicado os modelos de templates que este repositório suporta.

## Processo de solicitação de mudança (Merge Request)

1. Certifique-se de que foram realizados testes em todos os JOBs e steps utilizados no template;
2. Descreva em forma de comentário no corpo do template as variáveis necessárias para utilização do mesmo;
3. Aumenta os números da versão no arquivo de template.
3. Você poderá realizar o Merge, assim que tiver uma aprovação da cadeia de aprovadores do repositório;

