# **Template Store**
Loja oficial de templates Gitlab para CICD da Boa Vista SCPC.


## **Descrição**
Neste repositório contém templates com tudo necessário para o processo de build, [versionamento](https://gitlab.bvsnet.com.br/estruturantes/devsecjourney/bvs-semantic-version), testes de segurança, publicação de pacotes e deploy. 
A ideia é que todo processo desde o desenvolvimento do código até o momento que esse código seja deployado em algum ambiente, tenha um padrão e que esteja de acordo com a boas práticas estabelecidas na BVS. 

A utilização dos templates será obrigatória até o fim de 2021 para todos squads. Caso sua squad não se sinta atendida por algum dos templates disponibilizados, ou tenha alguma dúvida sobre sua utilização, por favor entre em contato com o [Squad DevSecOps Journey](https://boavistaservicos.atlassian.net.mcas.ms/wiki/spaces/TDS/pages/70811730/DevSec+Journey)
 .

## **Suporte para linguagens**
- Java
    - OpenJDK8
        -  Maven
    - OpenJDK11
        - Maven
- Dotnet Core 5
    - Nuget
- Javascript
    - NodeJS 12
        - npm
    - NodeJS 14
        - npm
    - NodeJS 17
        - npm
- Python
    - Python3
        - PyPi

## **Funcionamento**
Através da utilização dos jobs criados em https://gitlab.bvsnet.com.br/estruturantes/devsecjourney/devsecjourney-store , conseguimos criar uma esteira completa
com versionamento automatizado, build, testes unitários, testes de segurança, publicação de pacotes e deploy. Todos os jobs são instanciados baseados no gitflow
especificado abaixo
### **Gitflow**
Todos repositórios que vão utilizar a esteira devem conter 3 branchs: main, homolog, development. Onde o fluxo de atualização do versionamento deve ser sempre de alguma-feature-branch -> development -> homolog -> main .
As três branch devem ser protegidas e as atualizações devem acontecer através de MR.

**Código fonte, localização dos pacotes e deploy estarão sempre no mesmo ambiente**.

**Exemplo de Gitflow Correto**
![Exemplo de Gitflow Correto](assets/gitflow.png "Exemplo de Gitflow Correto")
Para casos de emergência há suporte para hotfix do qual o fluxo é hotfix-branch -> main. Logo depois pode-se atualizar as outras branch através do fluxo de atualização de main -> homolog -> development atráves de MR.


### **Versionamento**
Versionamento semântico automatizado baseado nas mensagens de commit.

Para realizar o bump de uma versão, basta que o nome da branch de origem originária para o merge request na branch de development contenha os seguintes prefixos:

- "breaking-": Bump da major
    - exemplos
        - breaking-firstcommit

- "feat-":  Bump da minor
    - exemplos
        - feat-nova-funcionalidade

- "fix-": Bump do patch
    - exemplos
        - fix-arrumando-typo

- "hotfix-": Quando a branch de origem mergeada a main cria uma tag com prefixo hotfix
    - exemplo
        - hotfix-condicao-nova

**enfatizamos que o fluxo precisa ser seguido de Branch de origem contendo prefixo>Development, Development>Homolog, Homolog>Main**

**Código fonte**: https://gitlab.bvsnet.com.br/estruturantes/devsecjourney/bvs-semantic-version

### **Build**
A build é realizada na MR, após mergeado o código fonte, a build é restaurada e publicada no Package Registry. 

O Package Registry está separado entre 3 ambientes: Development, Homolog e Produção. Os pacotes vão estar no mesmo ambiente que o código fonte e o deploy estão.

Exemplo: uma MR acaba de ser mergeada em development
- Uma nova tag é criada com a mesma versão do pacote
- O pacote é publicado no ambiente de development
- A nova versão do pacote é deployada no ambiente de development
### **Segurança**
Testes de segurança serão rodados por padrão, neles estão inclusos:
- SAST
- DAST
- Secret Detection
- Container Scanning

### **Code Quality**
Para code quality usaremos o sonar, que garantirá que o projeto siga a qualidade de código de acordo com o quality gate especificado 
### **Publicação**
Os pacotes serão publicados no Package Registry do Gitlab localizado em https://gitlab.bvsnet.com.br/estruturantes/devsecjourney/package-store, na aba "Packages & Registries" de cada repositório de ambiente correspondente.

As imagens docker serão publicadas no registry do projeto bvs-main-98cb

### **Deploy**
Para deploy será utilizado o bvs-publisher. Ele é responsável por renderizar yml's e aplicá-los no ambiente kubernetes.  

## **Utilização**
Para utilizar, basta apontar o gitlab-ci do seu repositório para este projeto e seguir os requisitos mínimos especificados a baixo para cada tipo de template.
- Para apontar vá até a seção settings/CICD do seu repositório
- Na caixa de texto CI/CD configuration file aponte o caminho 

exemplo: maven/service/openjdk11.yml@estruturantes/devsecjourney/devsecjourney-template-store

**Hierarquia de requisitos que cada tipo de projeto**
- Repositório
    - Serviço
        - Requisitos Dockerfile*
        - Tipo de pacote(maven, dotnetcore(nuget), npm, pypi)
    - Biblioteca
        - Requisitos Dockerfile*
        - Tipo de pacote(maven, dotnetcore(nuget), npm, pypi, docker)
    
\* Apenas para os que tiverem Dockerfile

Um projeto Docker é um projeto que não tem processo de build, por exemplo o bvs-publisher é um projeto bash, logo apenas queremos importar o código fonte para o Docker.  

**Exemplos:**

Um serviço maven openjdk11 deve seguir os seguintes requisitos
- Repositório
- Serviço
- Maven

Uma biblioteca Docker que **não** tem build deve seguir os seguintes requisitos:
- Repositório
- Docker

### **Requisitos do repositório**
- O repositório deve seguir a estrutura de grupos especificada aqui https://boavistaservicos.atlassian.net.mcas.ms/wiki/spaces/TDS/pages/95682902/Estrutura+de+grupos+subgrupos+e+projetos.
- 3 Branchs protegidas com o nome: main, homolog e development
    - cada branch se refere ao respetivo ambiente, onde main é o ambiente de produção 
- Todo merge request deve ser fast-foward e squash commits não são permitidos
    - Para editar as configurações acima entre em settings/general e vá a até a seção de merge requests
    - Escolha a opção "Fast-foward" merge na sub-seção "Merge method"
    - Escolha a opção "Do not allow" na sub-seção "Squash commits when merging"
- Adicione o usuário @gitlab-bot como owner do seu grupo.
    - O gitlab-bot é responsável por aplicar mudanças dos repositórios através de automações

### **Requisitos Dockerfile**
Caso exista um Dockerfile no repositório automaticamente a esteira irá dockeirizar sua aplicação e publicar a imagem Docker no registry oficial.
Para que funcione corretamente, o Dockerfile **não** deve buildar a aplicação, ele será apenas responsável por copiar o pacote gerado na fase Package.
A fase Package irá buildar o pacote e armazenar ele como um artefato no Gitlab, esse artefato será recuperado na fase Dockerize e pode ser utilizado pelo 
Dockerfile, logo, basta incluir a build gerada no Dockerfile para que sua aplicação seja Dockerizada.

### **Requisitos serviços**
Projetos que são serviços devem usar os templates que estão no diretório service. Esse diretório contém templates que possuem CD utilizando o bvs-publisher.
Variáveis de ambiente obrigatória:
- GKE_CLUSTER_MAPPING
    - JSON que possui referencia dos clusters de acordo com o ambiente
    - Exemplo:

            {
                "estruturantes": {
                    "production": {
                    "projectId": "bvs-main-98cb",
                    "clusterName": "bvs-main",
                    "zone": "southamerica-east1"
                    },
                    "homolog": {
                    "projectId": "homolog-c00b",
                    "clusterName": "general-cluster",
                    "zone": "southamerica-east1"
                    },
                    "development": {
                    "projectId": "dev-bvs-main-585d",
                    "clusterName": "gke-dev-bvs-main-cluster",
                    "zone": "us-east1"
                    },
                    "sandbox": {
                    "projectId": "sandbox-1c9f",
                    "clusterName": "gke-sandbox-cluster",
                    "zone": "southamerica-east1"
                    }
                }
            }
- GKE_NAMESPACE
    - variável que se refere a qual ambiente o arquivos k8s serão aplicados
- GKE_PUBLISH_DEV
    - variável que tem permissão para deploy no gke de dev
- GKE_PUBLISH_NP
    - variável que tem permissão para deploy no gke de homolog
- GKE_PUBLISH_PROD
    - variável que tem permissão para deploy no gke de produção
    
**IMPORTANTE**
NENHUMA VARIÁVEL PODE ESTAR CONFIGURADA COMO PROTECTED!


### **Requisitos para Projetos Maven**
Todos os projetos maven devem ter o pom.xml alterado para que seja renderizado as seguintes variáveis de ambiente:
- VARIAVEL_POM - VARIAVEL_AMBIENTE
    - ${artifactId} - APP_ARTIFACT_ID
    - ${version} - será automaticamente instanciado
    - ${groupId} - APP_GROUP_ID
    - ${description} - APP_DESCRIPTION

Exemplo de como fica as variáveis de ambiente no projeto:
![Exemplo de uso das variáveis obrigatórias](assets/exemplo-variaveis-projeto.png "Exemplo de uso das variáveis obrigatórias")

**Exemplo**

    <groupId>${groupId}</groupId>
    <artifactId>${artifactId}</artifactId>
    <version>${version}</version>
    <packaging>jar</packaging>
    <name>${artifactId}</name>
    <description>${description}</description>

Projeto exemplo: https://gitlab.bvsnet.com.br/estruturantes/devsecjourney/microservices/spring-openjdk11-example


### **Requisitos para Projetos NPM**
O único requisito é que o nome do pacote deve ter como prefixo bvs@ no package.json .

Exemplo:
- bvs@nome-exemplo

projeto exemplo: https://gitlab.bvsnet.com.br/estruturantes/devsecjourney/microservices/node-14-express-example

### **Requisitos para Projetos PyPi**
Variáveis obrigatórias:
- APP_ARTIFACT_ID
    - Nome do artefato que será publicado

O APP_ARTIFACT_ID será utilizado no `setup.py` . Você pode usar como referência o projeto https://gitlab.bvsnet.com.br/estruturantes/devsecjourney/microservices/python3-example

### **Requisitos para Projetos Dotnet**
Não há variáveis obrigatórias, apenas recomendações.
O pacote que vai ser publicado deve ter nome único, para isso siga como referencia sempre o nome do grupo e do repositório para que não haja problemas de conflito.

### **Requisitos para Projetos Docker**
Não há requisitos, todas variáveis são geradas usando os grupos, nome do projeto e o versionamento automatizado.


## **Contribuição**
Caso a mudança seja um novo job por favor siga a documentação do repositório https://gitlab.bvsnet.com.br/estruturantes/devsecjourney/devsecjourney-store.
Após criar o novo job, ou modifica-lo em um branch a parte, para testar o código sugerimos que seja utilizado um novo repositório contendo um código fonte simples, que não faça nenhum tipo de processamento crítico e siga os passos abaixo
- No repositório importado um template deste repositório, e o template deste repositório importará o template do devsecjourney-store, que contém o novo job ou sua modificação. Fazemos exatamente assim em cada template deste repositório, basta apontar para sua branch utilizando a variável ref.
- Você pode utilizar qualquer outro job já existente para concatenar à sua esteira de teste
- Sugerimos a utilização do CI lint do gitlab para testes de sintaxe rápidas. Ele fica localizado na sessão CICD/pipelines

Após finalizar os testes manuais, abra uma MR descrevendo a motivação e anexe os links de sucesso do job. É recomendado que a MR tenha apenas um commit e siga o padrão https://www.conventionalcommits.org/en/v1.0.0/

A MR relativa ao job deve ser mergeada antes de ser inclusa neste repositório

### **Maintainers**
[Squad DevSecOps Journey](https://boavistaservicos.atlassian.net.mcas.ms/wiki/spaces/TDS/pages/70811730/DevSec+Journey)
